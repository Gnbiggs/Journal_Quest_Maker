# QuestSmith — Quests.json Editor (RPG Maker MZ)

This is a single-file web app that helps you build `data/Quests.json` visually (no manual JSON typing).

## Use

1) Open `quest_editor.html` in your browser (double-click).
2) Add quests + stages.
3) Click **Export** (or press **Ctrl+S**) to download `Quests.json`.
4) Copy the exported file into your RPG Maker MZ project at:

`YourProject/data/Quests.json`

## Import existing quests

Click **Import** and select your current `Quests.json`.

## Optional: run a local server

If your browser is picky about opening local files, run:

```bash
python3 serve.py
```

Then open: http://localhost:8000/quest_editor.html
