import http.server
import socketserver
from pathlib import Path

PORT = 8000
HERE = Path(__file__).resolve().parent

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(HERE), **kwargs)

with socketserver.TCPServer(("", PORT), Handler) as httpd:
    print(f"Serving QuestSmith at http://localhost:{PORT}/quest_editor.html")
    httpd.serve_forever()
